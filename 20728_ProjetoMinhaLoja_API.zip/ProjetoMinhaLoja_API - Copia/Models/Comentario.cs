namespace ProjetoMinhaLoja_API.Models
{
    public class Comentario
    {
        public int id { get; set; }
      
        public string comentario { get; set; }
    }
}