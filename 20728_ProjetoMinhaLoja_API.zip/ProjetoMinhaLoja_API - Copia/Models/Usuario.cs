namespace ProjetoMinhaLoja_API.Models
{
    public class Usuario
    {
         public int id { get; set; }
      
        public string nome { get; set; }
      
        public string senha { get; set; }



    }
}